create view app_phase_view(id_on_market, phase) as
SELECT app.id_on_market,
       app_product.phase
FROM entity.app_product
         JOIN application.app ON app_product.id = app.app_product_id
WHERE app_product.phase <> 1;

alter table app_phase_view
    owner to project_full;

