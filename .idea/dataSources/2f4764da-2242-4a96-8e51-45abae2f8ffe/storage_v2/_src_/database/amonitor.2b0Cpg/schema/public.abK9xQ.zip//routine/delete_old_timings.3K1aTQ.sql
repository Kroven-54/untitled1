create function delete_old_timings() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE 
    FROM "service"."parsers_timings" 
    WHERE "id" IN (
        SELECT "id"
        FROM (
            SELECT "id", "timestamp", row_number() OVER w AS rank
            FROM "service"."parsers_timings"
            WINDOW w AS (PARTITION BY "route" ORDER BY "timestamp" DESC)
            ORDER BY "timestamp" DESC
        ) count_excess
        WHERE "count_excess"."timestamp" < NOW() - INTERVAL '7 days' AND rank > 20
    );
    RETURN NULL;
END;
$$;

alter function delete_old_timings() owner to project_full;

